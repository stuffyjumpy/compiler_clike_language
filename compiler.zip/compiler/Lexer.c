#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Lexer.h"
LTpair input[100000];
int inp_index=0;

//returns token for lexeme
int token(char buf[]){
		char *reserved[] = {"begin","end","","","","if","","","","","read","write","int","float","double","char","","else","","","","","for","while"};
		
		int i;
		int res_size = sizeof(reserved)/sizeof(reserved[0]) ;
		for(i=0;i<res_size;i++){
			if(strcmp(buf,reserved[i])==0)
				return i;
		}
		int token_num = tokenDFA(buf);
		return token_num;
}

//prints token for lexemes, prints errors
void printToken(char *lexeme, int line){
	int temp_token=token(lexeme);
	if(temp_token!=-1){
		strcpy(input[inp_index].lexeme,lexeme);
		input[inp_index].token = temp_token;
		input[inp_index].line = line;
		inp_index++;
	}
	else
		printf("ERROR in Line %d: %s not recognized\n",line,lexeme);
}

//finds token for non reserved words
int tokenDFA(char *s){
	int i=0,state=0;
	
	while(s[i]!='\0'){
		switch(state){
			case 0:	if(isalpha(s[i])){
						state=1;
					}
					else if(isdigit(s[i])){
						state=2;
					}
					else{
						switch(s[i]){
							case '\"': state=6; break;
							case '+': state=3; break;
							case '-': state=9; break;
							case '*': state=10; break;
							case '/': state=11; break;
							case '%': state=12; break;
							case '=': state=13; break;
							case '>': state=15; break;
							case '<': state=16; break;
							case '!': state=19; break;
							case '&': state=21; break;
							case '|': state=23; break;
							case '?': state=25; break;
							case ':': state=26; break;
							case '{': state=27; break;
							case '}': state=28; break;
							case '(': state=29; break;
							case ')': state=30; break;
							case '[': state=31; break;
							case ']': state=32; break;	
							case ';': state=33;	break;
							case ',': state=34; break;
							default: return -1;
						}
					}
					i++;
					break;
			case 1: if(isalpha(s[i]) || isdigit(s[i]) || s[i]=='_'){
						state=1;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 2: if(isdigit(s[i])){
						state=2;
					}
					else if(s[i]=='.'){
						state=4;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 3: if(isdigit(s[i])){
						state=2;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 4: if(isdigit(s[i])){
						state=5;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 5: if(isdigit(s[i])){
						state=5;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 6: if(s[i]=='\\'){
						state=8;
					}
					else if(s[i]=='\"'){
						state=7;
					}
					else if(s[i]!='\n' && s[i]!='\t' && s[i]!=' '){
						state=6;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 7: return -1;
					break;
			case 8: if(s[i]=='t' || s[i]=='n' || s[i]=='r' || s[i]=='\"' || s[i]=='\\'){
						state=6	;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 9: if(isdigit(s[i])){
						state=2;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 13: if(s[i]=='='){
						state=14;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 15: if(s[i]=='='){
						state=17;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 16: if(s[i]=='='){
						state=18;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 19: if(s[i]=='='){
						state=20;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 21: if(s[i]=='&'){
						state=22;
					}
					else{
						return -1;
					}
					i++;
					break;
			case 23: if(s[i]=='|'){
						state=24;
					}
					else{
						return -1;
					}
					i++;
					break;

			default: return -1; 					
		}
	}
	// return the token corresponding to the final state in DFA
	switch(state){
		case 1: return IDENTIFIER;
		case 2: return INT_CONST;
		case 3: return PLUS_OP;
		case 5: return FLOAT_CONST;
		case 7: return STRING_CONST;
		case 9: return MINUS_OP;
		case 10: return MUL_OP;
		case 11: return DIV_OP;
		case 12: return MOD_OP;
		case 13: return ASSIG_OP;
		case 14: return EQUAL_OP;
		case 15: return GT_OP;
		case 16: return LT_OP;
		case 17: return GTE_OP;
		case 18: return LTE_OP;
		case 19: return NEG_OP;
		case 20: return NE_OP;
		case 22: return AND_OP;
		case 24: return OR_OP;
		case 25: return COND_OP;
		case 26: return COND_OP2;
		
		case 27: return OPEN_BRACE;	
		case 28: return CLOSE_BRACE;
		case 29: return OPEN_PAR;
		case 30: return CLOSE_PAR;
		case 31: return OPEN_SQ;
		case 32: return CLOSE_SQ;
		case 33: return SEMI_COL;
		case 34: return COMMA;
		default: return -1;
	}
}
