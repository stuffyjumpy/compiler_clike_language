#ifndef LEXER_H_INCLUDED
#define LEXER_H_INCLUDED

// all possible lexemes
#define IDENTIFIER 2
#define INT_CONST 31
#define FLOAT_CONST 32
#define STRING_CONST 33
#define PLUS_OP 18
#define MINUS_OP 19
#define MUL_OP 20
#define DIV_OP 21
#define MOD_OP -1
#define ASSIG_OP 4
#define EQUAL_OP 30
#define GT_OP 27
#define LT_OP 26
#define GTE_OP 29
#define LTE_OP 28
#define NEG_OP -1
#define NE_OP -1
#define AND_OP 24
#define OR_OP 25
#define COND_OP -1
#define COND_OP2 -1
#define OPEN_BRACE 8
#define CLOSE_BRACE 9
#define OPEN_PAR 6
#define CLOSE_PAR 7
#define OPEN_SQ -1
#define CLOSE_SQ -1
#define SEMI_COL 3
#define COMMA 16
#define $ 34

//store lexeme token pairs
typedef struct ltpair{
	char lexeme[25];	
	int token;			
	int line;
} LTpair;

int token(char *);	//returns token for lexeme
int tokenDFA(char *);	//returns token if not reserved word
void printToken(char *,int line);	//prints token number and errors

#endif
