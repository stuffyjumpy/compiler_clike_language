#include <stdio.h>
#include <stdlib.h>
#include "Lexer.h"
#include "Parser.h"
#include "Tree.h"
cell a[100][58];
Tnode* root;

//finds index of NT in parse table
int indexOf(char *NT){
	int i;
	for(i=0;i<=22;i++){
		if(strcmp(Goto[i],NT)==0){
			return i+35;
		}
	}
	return -1;
}

//parses using LALR
void parse(LTpair input[], int n,Tnode **rootptr){
	initialize();
	int i,j;

	//prints table
	printf("\n\n\nPARSE TABLE\n\n\n");
	for(i=0;i<=99;i++){
		for(j=0;j<58;j++){
			printf("%d %d -- ", a[i][j].state, a[i][j].action);
		}
		printf("\n\n");
	}

	int S1[100000];		// Stack of States
	Tnode *S2[100000] = {NULL};	// Stack of items in RHS of a production, to be reduced further
	
	memset(S1,-1,sizeof(S1));

	int top1=-1,top2=-1;	
	int cip = 0;		// current input index , in the input[] array of struct
	
	S1[++top1]=0;		// Push State0 onto stack
	printf("\n\n\n");
	int count = 0;
	printf("\n\n\nPARSING STEPS\n\n\n");
	while(top2!=0 || (top2==0 && strcmp(S2[top2]->text,"Program")!=0)){
		int i;
		printf("Step %d:\n", count);
		printf("Stack contents: ");
		for(i=0;i<=top1;i++){
			printf("%d ",S1[i]);
			if(S2[i]!=NULL)
				printf("%s ",S2[i]->text);
		}
		printf("\nLeftover Input: ");
		for(i=cip;i<=cip+5;i++)
			printf("%d ",input[i].token);
		printf("\n");
		int act,next;
		if(top1==top2){	// Use Goto table
			int goto_index = indexOf(S2[top2]->text);
			act  = 4;
			next = a[S1[top1]][ goto_index].state;
		}
		else{	// Use Shift-Reduce Table
			act = a[ S1[top1] ][ input[cip].token ].action;			// action
			next = a[ S1[top1] ][ input[cip].token ].state;			// next state /
		}
		printf("Action: %d\nNext State:%d",act,next);
		int out=0;
		switch(act){
			case ERROR: printf("\nERROR: %s is not expected at Line %d\n",input[cip].lexeme,input[cip].line);
						int temp_top1 = top1;
						int temp_top2 = top2;
						while(1){
							top1--;
							top2--;
							if(top1>=0 && a[ S1[top1]  ][ input[cip].token ].action!=0){
								int i;
								for(i=top1+1;i<=temp_top1;i++){
									S1[i]=-1;
								}
								for(i=top2+1;i<=temp_top2;i++){
									S2[i]=NULL;
								}
								break;				
							}
							else if(top1>=0)
								continue;
							else if(input[cip].token == $){
								printf("Complete input is absorbed. The program can't be parsed.\n");
								exit(0);
							}
							
							else{
								top1 = temp_top1;
								top2 = temp_top2;
								cip++;
							}

						}
							
						break;
			case SHIFT: ;
						Tnode *x = newTnode(input[cip].lexeme);
						S2[++top2] = x;
						S1[++top1] = next;
						cip++;	
						break;
			case ACCEPT:
			case REDUCE: ;
						char parent_lex[25];
						strcpy(parent_lex,LHS[next]);
						Tnode *parent = newTnode(parent_lex);	
						int i;
						for(i=0;i < plen[next];i++){
							parent->child[i] = S2[top2 - plen[next] + 1 + i];
							S2[top2 - plen[next] + 1 + i] = NULL;
							S1[top1]=-1;
							top1--;
						}
						top2 = top2 - plen[next];
						S2[++top2] = parent;
						break;

			case BLANK: S1[++top1] = next;
		}
		count++;
		printf("\n\n");
	}
	printf("\nACCEPTED.\n");
	*rootptr = S2[top2];
	return;
}

//fills parse table based on grammar
void initialize(){
	int i,j,k;
	for(i=0;i<100;i++){
		for(j=0;j<50;j++)
		{
			a[i][j].state=0;
			a[i][j].action=0;
		}
	}
	a[0][0].action=1;
	a[0][0].state=1;
	a[1][1].action=2;
	a[1][1].state=2;
	a[1][2].action=1;
	a[1][2].state=10;
	a[1][5].action=1;
	a[1][5].state=11;
	a[1][10].action=1;
	a[1][10].state=14;
	a[1][11].action=1;
	a[1][11].state=15;
	a[1][12].action=1;
	a[1][12].state=16;
	a[1][13].state=17;
	a[1][13].action=1;
	a[1][14].action=1;
	a[1][14].state=18;
	a[1][15].action=1;
	a[1][15].state=19;
	a[1][22].state=20;
	a[1][22].action=1;
	a[1][23].state=21;
	a[1][23].action=1;
	for(i=0;i<100;i++)
		for(j=35;j<58;j++)
			a[i][j].action=4;
			
	a[22][34].action=3;		// Accepted state

a[1][36].state=2;
a[1][37].state=3;
a[1][38].state=4;
a[1][39].state=5;
a[1][40].state=6;
a[1][41].state=7;
a[1][42].state=8;
a[1][43].state=9;
a[1][52].state=12;
a[1][53].state=13;

a[2][1].state=22;
a[2][1].action=1;
a[3][1].action=2;
a[3][1].state=2;
a[3][2].state=10;
a[3][2].action=1;
a[3][5].action=1;
a[3][5].state=11;
a[3][9].state=2;
a[3][9].action=2;
a[3][10].state=14;
a[3][10].action=1;
a[3][11].action=1;
a[3][11].state=15;
a[3][12].action=1;
a[3][12].state=16;
a[3][13].action=1;
a[3][13].state=17;
a[3][14].action=1;
a[3][14].state=18;
a[3][15].action=1;
a[3][15].state=19;
a[3][22].action=1;
a[3][22].state=20;
a[3][23].state=21;
a[3][23].action=1;
a[3][36].state=23;
a[3][37].state=3;
a[3][38].state=4;
a[3][39].state=5;
a[3][40].state=6;
a[3][41].state=7;
a[3][42].state=8;
a[3][43].state=9;
a[3][52].state=12;
a[3][53].state=13;
a[4][1].state=3;
a[4][1].action=2;
a[4][2].state=3;
a[4][2].action=2;
a[4][5].action=2;
a[4][5].state=3;
for(i=9;i<=15;i++)
	a[4][i]=a[4][5];
a[4][22]=a[4][5];
a[4][23]=a[4][22];
for(i=0;i<58;i++)
	a[5][i]=a[4][i];
a[5][1].state=a[4][1].state+1;
a[5][2].state=a[4][2].state+1;
a[5][5].state=a[4][5].state+1;
a[5][9].state=a[4][9].state+1;
a[5][10].state=a[4][10].state+1;
a[5][11].state=a[4][11].state+1;
a[5][12].state=a[4][12].state+1;
a[5][13].state=a[4][13].state+1;
a[5][14].state=a[4][14].state+1;
a[5][15].state=a[4][15].state+1;
a[5][22].state=a[4][22].state+1;
a[5][23].state=a[4][23].state+1;
for(j=6;j<=8;j++)
	for(i=0;i<58;i++)
		a[j][i]=a[j-1][i];
for(j=48;;){
	for(i=0;i<58;i++)
		a[j][i]=a[7][i];
	if(j>=50)
		break;
	j=j+2;	
}
a[6][1].state=a[5][1].state+1;
a[6][2].state=a[5][2].state+1;
a[6][5].state=a[5][5].state+1;
a[6][9].state=a[5][9].state+1;
a[6][10].state=a[5][10].state+1;
	a[6][11].state=a[5][11].state+1;
	a[6][12].state=a[5][12].state+1;
	a[6][13].state=a[5][13].state+1;
	a[6][14].state=a[5][14].state+1;
	a[6][15].state=a[5][15].state+1;
	a[6][22].state=a[5][22].state+1;
	a[6][23].state=a[5][23].state+1;
a[7][1].state=a[6][1].state+1;
a[7][2].state=a[6][2].state+1;
a[7][5].state=a[6][5].state+1;
a[7][9].state=a[6][9].state+1;
a[7][10].state=a[6][10].state+1;
	a[7][11].state=a[6][11].state+1;
	a[7][12].state=a[6][12].state+1;
	a[7][13].state=a[6][13].state+1;
	a[7][14].state=a[6][14].state+1;
	a[7][15].state=a[6][15].state+1;
	a[7][22].state=a[6][22].state+1;
	a[7][23].state=a[6][23].state+1;
a[8][1].state=a[7][1].state+1;
a[8][2].state=a[7][2].state+1;
a[8][5].state=a[7][5].state+1;
a[8][9].state=a[7][9].state+1;
a[8][10].state=a[7][10].state+1;
	a[8][11].state=a[7][11].state+1;
	a[8][12].state=a[7][12].state+1;
	a[8][13].state=a[7][13].state+1;
	a[8][14].state=a[7][14].state+1;
	a[8][15].state=a[7][15].state+1;
	a[8][22].state=a[7][22].state+1;
	a[8][23].state=a[7][23].state+1;
	a[9][2].state=24;
	a[9][2].action=1;
	a[10][4].state=25;
	a[10][4].action=1;
	a[11][6].state=26;
	a[11][6].action=1;
for(j=12;j<=13;j++)
	for(i=0;i<58;i++)
		a[j][i]=a[8][i];
a[12][1].state=a[7][2].state+5;
a[12][2].state=a[7][2].state+5;
a[12][5].state=a[7][5].state+5;
a[12][9].state=a[7][9].state+5;
a[12][10].state=a[7][10].state+5;
a[12][11].state=a[7][11].state+5;
a[12][12].state=a[7][12].state+5;
a[12][13].state=a[7][13].state+5;
a[12][14].state=a[7][14].state+5;
a[12][15].state=a[7][15].state+5;
a[12][22].state=a[7][22].state+5;
a[12][23].state=a[7][23].state+5;
a[13][1].state=a[7][1].state+6;
a[13][2].state=a[7][2].state+6;
a[13][5].state=a[7][5].state+6;
a[13][9].state=a[7][9].state+6;
a[13][10].state=a[7][10].state+6;
	a[13][11].state=a[7][11].state+6;
	a[13][12].state=a[7][12].state+6;
	a[13][13].state=a[7][13].state+6;
	a[13][14].state=a[7][14].state+6;
	a[13][15].state=a[7][15].state+6;
	a[13][22].state=a[7][22].state+6;
	a[13][23].state=a[7][23].state+6;
	a[14][2].state=27;
	a[14][2].action=1;
	a[15][2].state=29;
	a[15][2].action=1;
	a[15][31].state=31;
	a[15][32].state=32;
	a[15][33].state=33;
	a[15][31].action=1;
	a[15][32].action=1;
	a[15][33].action=1;
	a[15][44].state=28;
	a[15][57].state=30;
	a[16][2].action=2;
	a[16][2].state=15;
	a[17][2].action=2;
	a[17][2].state=16;
	a[18][2].action=2;
	a[18][2].state=17;
	a[19][2].action=2;
	a[19][2].state=18;
	a[20][6].state=34;
	a[20][6].action=1;
	a[21][6].state=35;
	a[21][6].action=1;
	a[22][34].action=3;
	a[23][1].state=1;
	a[23][1].action=2;
	a[23][9].action=2;
	a[23][9].state=1;
	a[24][3].action=2;
	a[24][3].state=22;
	a[24][16].state=37;
	a[24][16].action=1;
	a[24][45].state=36;
	a[25][2].state=29;
	a[25][2].action=1;
	a[25][31].state=31;
	a[25][32].state=32;
	a[25][33].state=33;
	a[25][31].action=1;
	a[25][32].action=1;
	a[25][33].action=1;
	a[25][44].state=40;
	a[25][48].state=38;
	a[25][49].state=39;
	a[25][57].state=30;
	a[26][2].state=29;
	a[26][2].action=1;
	a[26][31].state=31;
	a[26][32].state=32;
	a[26][33].state=33;
	a[26][31].action=1;
	a[26][32].action=1;
	a[26][33].action=1;
	a[26][44].state=43;
	a[26][46].state=41;
	a[26][54].state=42;
	a[26][57].state=30;
	a[27][3].state=22;
	a[27][3].action=2;
	a[27][16].state=37;
	a[27][16].action=1;
	a[27][45].state=44;
	a[28][3].state=22;
	a[28][3].action=2;
	a[28][16].state=37;
	a[28][16].action=1;
	a[28][45].state=45;
	a[29][1].state=19;
	a[29][1].action=2;
	a[29][2].state=19;
	a[29][2].action=2;
	a[29][3].state=19;
	a[29][3].action=2;
	a[29][5].state=19;
	a[29][5].action=2;
	a[29][7].state=19;
	a[29][7].action=2;
	a[29][9].state=19;
	a[29][9].action=2;
	a[29][10].state=19;
	a[29][10].action=2;
	a[29][11].state=19;
	a[29][11].action=2;
	a[29][12].state=19;
	a[29][12].action=2;
	a[29][13].state=19;
	a[29][13].action=2;
	a[29][14].state=19;
	a[29][14].action=2;
	a[29][15].state=19;
	a[29][15].action=2;
	a[29][16].state=19;
	a[29][16].action=2;
	a[29][18].state=19;
	a[29][18].action=2;
	for(j=19;j<=30;j++)
	{
	a[29][j].state=19;
	a[29][j].action=2;
	
	}
	for(j=30;j<34;j++){
		for(i=0;i<58;i++){
			a[j][i].action=a[29][i].action;
		}
	}
	a[30][1].state=20;
	a[30][2].state=20;
	a[30][3].state=20;
	a[30][5].state=20;
	a[30][7].state=20;
	a[30][9].state=20;
	a[30][10].state=20;
	a[30][11].state=20;
	a[30][12].state=20;
	a[30][13].state=20;
	a[30][14].state=20;
	a[30][15].state=20;
	a[30][16].state=20;
	a[30][18].state=20;
	a[30][19].state=20;
	a[30][20].state=20;
	a[30][21].state=20;
	a[30][22].state=20;
	a[30][23].state=20;
	a[30][24].state=20;
	a[30][25].state=20;
	a[30][26].state=20;
	a[30][27].state=20;
	a[30][28].state=20;
	a[30][29].state=20;
	a[30][30].state=20;
		
	a[31][1].state=45;
	a[31][2].state=45;
	a[31][3].state=45;
	a[31][5].state=45;
	a[31][7].state=45;
	a[31][9].state=45;
	a[31][10].state=45;
	a[31][11].state=45;
	a[31][12].state=45;
	a[31][13].state=45;
	a[31][14].state=45;
	a[31][15].state=45;
	a[31][16].state=45;

	a[31][18].state=45;
	a[31][19].state=45;
	a[31][20].state=45;
	a[31][21].state=45;
	a[31][22].state=45;
	a[31][23].state=45;
	a[31][24].state=45;
	a[31][25].state=45;
	a[31][26].state=45;
	a[31][27].state=45;
	a[31][28].state=45;
	a[31][29].state=45;
	a[31][30].state=45;
	
	a[32][1].state=46;
	a[32][2].state=46;
	a[32][3].state=46;
	a[32][5].state=46;
	a[32][7].state=46;
	a[32][9].state=46;
	a[32][10].state=46;
	a[32][11].state=46;
	a[32][12].state=46;
	a[32][13].state=46;
	a[32][14].state=46;
	a[32][15].state=46;
	a[32][16].state=46;
	a[32][18].state=46;
	a[32][19].state=46;
	a[32][20].state=46;
	a[32][21].state=46;
	a[32][22].state=46;
	a[32][23].state=46;
	a[32][24].state=46;
	a[32][25].state=46;
	a[32][26].state=46;
	a[32][27].state=46;
	a[32][28].state=46;
	a[32][29].state=46;
	a[32][30].state=46;
	a[33][1].state=47;
	a[33][2].state=47;
	a[33][3].state=47;
	a[33][5].state=47;
	a[33][7].state=47;
	a[33][9].state=47;
	a[33][10].state=47;
	a[33][11].state=47;
	a[33][12].state=47;
	a[33][13].state=47;
	a[33][14].state=47;
	a[33][15].state=47;
	a[33][16].state=47;
	a[33][18].state=47;
	a[33][19].state=47;
	a[33][20].state=47;
	a[33][21].state=47;
	a[33][22].state=47;
	a[33][23].state=47;
	a[33][24].state=47;
	a[33][25].state=47;
	a[33][26].state=47;
	a[33][27].state=47;
	a[33][28].state=47;
	a[33][29].state=47;
	a[33][30].state=47;
	a[34][2].state=10;
	a[34][2].action=1;
	a[34][39].state=46;
	a[35][2].state=29;
	a[35][2].action=1;
	a[35][31].state=31;
	a[35][32].state=32;
	a[35][33].state=33;
	a[35][31].action=1;
	a[35][32].action=1;
	a[35][33].action=1;
	a[35][44].state=43;
	a[35][46].state=47;
	a[35][54].state=42;
	a[35][57].state=30;
	a[36][3].state=48;
	a[36][3].action=1;
	a[37][2].state=49;
	a[37][2].action=1;
	a[38][3].state=50;
	a[38][3].action=1;
	a[39][3].state=31;
	a[39][3].action=2;
	a[39][18].state=52;
	a[39][19].state=53;
	a[39][18].action=1;
	a[39][19].action=1;
	a[39][50].state=51;
	a[40][51].state=54;
	a[40][3].state=34;
	a[40][3].action=2;
	a[40][18].state=34;
	a[40][19].state=34;
	a[40][20].state=55;
	a[40][21].state=56;
	a[40][18].action=2;
	a[40][19].action=2;
	a[40][20].action=1;
	a[40][21].action=1;
	a[41][7].state=57;
	a[41][7].action=1;
	a[42][3].state=24;
	a[42][7].state=24;
	a[42][3].action=2;
	a[42][7].action=2;
	a[42][24].state=59;
	a[42][25].state=60;
	a[42][24].action=1;
	a[42][25].action=1;
	a[42][55].state=58;
	a[43][56].state=61;
	a[43][26].state=62;
	a[43][26].action=1;
	for(i=27;i<=30;i++){
		a[43][i].state=a[43][i-1].state+1;
		a[43][i].action=a[43][26].action;
	}
	a[44][3].state=67;
	a[44][3].action=1;
	a[45][3].state=68;
	a[45][3].action=1;
	a[46][2].state=29;
	a[46][2].action=1;
	a[46][31].state=31;
	a[46][32].state=32;
	a[46][33].state=33;
	a[46][31].action=1;
	a[46][32].action=1;
	a[46][33].action=1;
	a[46][44].state=43;
	a[46][46].state=69;
	a[46][54].state=42;
	a[46][57].state=30;
	a[47][7].state=70;
	a[47][7].action=1;
	a[48][1].state=a[7][1].state+2;
a[48][2].state=a[7][2].state+2;
a[48][5].state=a[7][5].state+2;
a[48][9].state=a[7][9].state+2;
a[48][10].state=a[7][10].state+2;
	a[48][11].state=a[7][11].state+2;
	a[48][12].state=a[7][12].state+2;
	a[48][13].state=a[7][13].state+2;
	a[48][14].state=a[7][14].state+2;
	a[48][15].state=a[7][15].state+2;
	a[48][22].state=a[7][22].state+2;
	a[48][23].state=a[7][23].state+2;
	a[50][1].state=a[7][1].state+3;
a[50][2].state=a[7][2].state+3;
a[50][5].state=a[7][5].state+3;
a[50][7] = a[50][5];
a[50][9].state=a[7][9].state+3;
a[50][10].state=a[7][10].state+3;
	a[50][11].state=a[7][11].state+3;
	a[50][12].state=a[7][12].state+3;
	a[50][13].state=a[7][13].state+3;
	a[50][14].state=a[7][14].state+3;
	a[50][15].state=a[7][15].state+3;
	a[50][22].state=a[7][22].state+3;
	a[50][23].state=a[7][23].state+3;
	a[50][31].state=9;
	a[50][32].state=9;
	a[50][33].state=9;
	a[50][31].action=2;
	a[50][32].action=2;
	a[50][33].action=2;
	a[49][3].state=22;
	a[49][3].action=2;
	a[49][16].state=37;
	a[49][16].action=1;
	a[49][45].state=71;
	a[51][3].state=27;
	a[51][3].action=2;
	a[52][2].state=29;
	a[52][2].action=1;
	a[52][31].state=31;
	a[52][32].state=32;
	a[52][33].state=33;
	a[52][31].action=1;
	a[52][32].action=1;
	a[52][33].action=1;
	a[52][44].state=40;
	a[52][49].state=72;
	a[52][57].state=30;
	for(i=0;i<58;i++)
		a[53][i]=a[52][i];
	a[53][49].state=73;
	a[54][3].state=28;
	a[54][3].action=2;
	a[54][18].state=28;
	a[54][19].state=28;
	a[54][18].action=2;
	a[54][19].action=2;
	for(i=0;i<58;i++)
		a[55][i]=a[52][i];
	for(i=0;i<58;i++)
		a[56][i]=a[52][i];
a[55][44].state=74;
a[55][49].state=0;
a[56][44].state=75;
a[56][49].state=0;
a[57][8].state=76;
a[57][8].action=1;
	for(i=0;i<58;i++)
		a[58][i]=a[52][i];
	a[58][44].state=43;
	a[58][46].state=77;
	a[58][54].state=42;
	a[58][57].state=30;
	a[58][49].state=0;
	a[59][2].state=38;
	a[59][2].action=2;
	a[60][2].state=39;
	a[60][2].action=2;
	a[60][31].state=39;
	a[60][32].state=39;
	a[60][33].state=39;
	a[60][31].action=2;
	a[60][32].action=2;
	a[60][33].action=2;
	a[59][31].state=38;
	a[59][32].state=38;
	a[59][33].state=38;
	a[59][31].action=2;
	a[59][32].action=2;
	a[59][33].action=2;
	a[61][2].state=29;
	a[61][2].action=1;
	a[61][31].state=31;
	a[61][32].state=32;
	a[61][33].state=33;
	a[61][31].action=1;
	a[61][32].action=1;
	a[61][33].action=1;
	a[61][44].state=78;
	a[61][57].state=30;
	k=40;
	for(j=62;j<=66;j++){
		for(i=0;i<58;i++){
			if(a[60][i].state>0){
				a[j][i].state=k;
				a[j][i].action=a[60][i].action;
    		}
    		else
			    a[j][i]=a[60][i];
		}
		k++;
	}

k=13;
for(j=67;j<=68;j++)
{
	for(i=0;i<58;i++)
	{
		if(a[50][i].state>0 && i<31)
		{
			a[j][i].state=k;
			a[j][i].action=a[50][i].action;
		}
	}
	k++;
}
a[69][3].state=79;
a[69][3].action=1;

a[70][8].action = 1 ;
a[70][8].state = 80 ;

a[71][3].action = 2 ;
a[71][3].state = 21 ;

a[72][3].action = 2 ;
a[72][3].state = 31 ;
a[72][18].action = 1 ;
a[72][18].state = 52 ;
a[72][19].action = 1 ;
a[72][19].state = 53 ;
a[72][50].action = 4 ;
a[72][50].state = 81 ;

a[73][3].action = 2 ;
a[73][3].state = 31 ;
a[73][18].action = 1 ;
a[73][18].state = 52 ;
a[73][19].action = 1 ;
a[73][19].state = 53 ;
a[73][50].action = 4 ;
a[73][50].state = 82 ;

a[74][3].action = 2 ;
a[74][3].state = 34 ;
a[74][18].action = 2 ;
a[74][18].state = 34 ;
a[74][19].action = 2 ;
a[74][19].state = 34 ;
a[74][20].action = 1 ;
a[74][20].state = 55 ;
a[74][21].action = 1 ;
a[74][21].state = 56 ;
a[74][51].action = 4 ;
a[74][51].state = 83 ;

a[75][3].action = 2 ;
a[75][3].state = 34 ;
a[75][18].action = 2 ;
a[75][18].state = 34 ;
a[75][19].action = 2 ;
a[75][19].state = 34 ;
a[75][20].action = 1 ;
a[75][20].state = 55 ;
a[75][21].action = 1 ;
a[75][21].state = 56 ;
a[75][51].action = 4 ;
a[75][51].state = 84 ;

a[76][2].action = 1 ;
a[76][2].state = 10 ;
a[76][5].action = 1 ;
a[76][5].state = 11 ;
a[76][9].action = 2 ;
a[76][9].state = 2 ;
a[76][10].action = 1 ;
a[76][10].state = 14 ;
a[76][11].action = 1 ;
a[76][11].state = 15 ;
a[76][12].action = 1 ;
a[76][12].state = 16 ;
a[76][13].action = 1 ;
a[76][13].state = 17 ;
a[76][14].action = 1 ;
a[76][14].state = 18 ;
a[76][15].action = 1 ;
a[76][15].state = 19 ;
a[76][22].action = 1 ;
a[76][22].state = 20 ;
a[76][23].action = 1 ;
a[76][23].state = 21 ;
a[76][36].action = 4 ;
a[76][36].state = 85 ;
a[76][37].action = 4 ;
a[76][37].state = 3 ;
a[76][38].action = 4 ;
a[76][38].state = 4 ;
a[76][39].action = 4 ;
a[76][39].state = 5 ;
a[76][40].action = 4 ;
a[76][40].state = 6 ;
a[76][41].action = 4 ;
a[76][41].state = 7 ;
a[76][42].action = 4 ;
a[76][42].state = 8 ;
a[76][43].action = 4 ;
a[76][43].state = 9 ;
a[76][52].action = 4 ;
a[76][52].state = 12 ;
a[76][53].action = 4 ;
a[76][53].state = 13 ;

a[77][3].action = 2 ;
a[77][3].state = 23 ;
a[77][7].action = 2 ;
a[77][7].state = 23 ;

a[78][3].action = 2 ;
a[78][3].state = 37 ;
a[78][7].action = 2 ;
a[78][7].state = 37 ;
a[78][24].action = 2 ;
a[78][24].state = 37 ;
a[78][25].action = 2 ;
a[78][25].state = 37 ;

a[79][2].action = 1 ;
a[79][2].state = 10 ;
a[79][39].action = 4 ;
a[79][39].state = 86 ;

a[80][2].action = 1 ;
a[80][2].state = 10 ;
a[80][5].action = 1 ;
a[80][5].state = 11 ;
a[80][9].action = 2 ;
a[80][9].state = 2 ;
a[80][10].action = 1 ;
a[80][10].state = 14 ;
a[80][11].action = 1 ;
a[80][11].state = 15 ;
a[80][12].action = 1 ;
a[80][12].state = 16 ;
a[80][13].action = 1 ;
a[80][13].state = 17 ;
a[80][14].action = 1 ;
a[80][14].state = 18 ;
a[80][15].action = 1 ;
a[80][15].state = 19 ;
a[80][22].action = 1 ;
a[80][22].state = 20 ;
a[80][23].action = 1 ;
a[80][23].state = 21 ;
a[80][36].action = 4 ;
a[80][36].state = 87 ;
a[80][37].action = 4 ;
a[80][37].state = 3 ;
a[80][38].action = 4 ;
a[80][38].state = 4 ;
a[80][39].action = 4 ;
a[80][39].state = 5 ;
a[80][40].action = 4 ;
a[80][40].state = 6 ;
a[80][41].action = 4 ;
a[80][41].state = 7 ;
a[80][42].action = 4 ;
a[80][42].state = 8 ;
a[80][43].action = 4 ;
a[80][43].state = 9 ;
a[80][52].action = 4 ;
a[80][52].state = 12 ;
a[80][53].action = 4 ;
a[80][53].state = 13 ;

a[81][3].action = 2 ;
a[81][3].state = 29 ;

a[82][3].action = 2 ;
a[82][3].state = 30 ;

a[83][3].action = 2 ;
a[83][3].state = 32 ;
a[83][18].action = 2 ;
a[83][18].state = 32 ;
a[83][19].action = 2 ;
a[83][19].state = 32 ;

a[84][3].action = 2 ;
a[84][3].state = 33 ;
a[84][18].action = 2 ;
a[84][18].state = 33 ;
a[84][19].action = 2 ;
a[84][19].state = 33 ;

a[85][9].action = 1 ;
a[85][9].state = 88 ;

a[86][7].action = 1 ;
a[86][7].state = 89 ;

a[87][9].action = 1 ;
a[87][9].state = 90 ;

a[88][1].action = 2 ;
a[88][1].state = 26 ;
a[88][2].action = 2 ;
a[88][2].state = 26 ;
a[88][5].action = 2 ;
a[88][5].state = 26 ;
a[88][9].action = 2 ;
a[88][9].state = 26 ;
a[88][10].action = 2 ;
a[88][10].state = 26 ;
a[88][11].action = 2 ;
a[88][11].state = 26 ;
a[88][12].action = 2 ;
a[88][12].state = 26 ;
a[88][13].action = 2 ;
a[88][13].state = 26 ;
a[88][14].action = 2 ;
a[88][14].state = 26 ;
a[88][15].action = 2 ;
a[88][15].state = 26 ;
a[88][17].action = 1 ;
a[88][17].state = 92 ;
a[88][22].action = 2 ;
a[88][22].state = 26 ;
a[88][23].action = 2 ;
a[88][23].state = 26 ;
a[88][47].action = 4 ;
a[88][47].state = 91 ;

a[89][8].action = 1 ;
a[89][8].state = 93 ;

a[90][1].action = 2 ;
a[90][1].state = 36 ;
a[90][2].action = 2 ;
a[90][2].state = 36 ;
a[90][5].action = 2 ;
a[90][5].state = 36 ;
a[90][9].action = 2 ;
a[90][9].state = 36 ;
a[90][10].action = 2 ;
a[90][10].state = 36 ;
a[90][11].action = 2 ;
a[90][11].state = 36 ;
a[90][12].action = 2 ;
a[90][12].state = 36 ;
a[90][13].action = 2 ;
a[90][13].state = 36 ;
a[90][14].action = 2 ;
a[90][14].state = 36 ;
a[90][15].action = 2 ;
a[90][15].state = 36 ;
a[90][22].action = 2 ;
a[90][22].state = 36 ;
a[90][23].action = 2 ;
a[90][23].state = 36 ;

a[91][1].action = 2 ;
a[91][1].state = 10 ;
a[91][2].action = 2 ;
a[91][2].state = 10 ;
a[91][5].action = 2 ;
a[91][5].state = 10 ;
a[91][9].action = 2 ;
a[91][9].state = 10 ;
a[91][10].action = 2 ;
a[91][10].state = 10 ;
a[91][11].action = 2 ;
a[91][11].state = 10 ;
a[91][12].action = 2 ;
a[91][12].state = 10 ;
a[91][13].action = 2 ;
a[91][13].state = 10 ;
a[91][14].action = 2 ;
a[91][14].state = 10 ;
a[91][15].action = 2 ;
a[91][15].state = 10 ;
a[91][22].action = 2 ;
a[91][22].state = 10 ;
a[91][23].action = 2 ;
a[91][23].state = 10 ;

a[92][8].action = 1 ;
a[92][8].state = 94 ;

a[93][2].action = 1 ;
a[93][2].state = 10 ;
a[93][5].action = 1 ;
a[93][5].state = 11 ;
a[93][9].action = 2 ;
a[93][9].state = 2 ;
a[93][10].action = 1 ;
a[93][10].state = 14 ;
a[93][11].action = 1 ;
a[93][11].state = 15 ;
a[93][12].action = 1 ;
a[93][12].state = 16 ;
a[93][13].action = 1 ;
a[93][13].state = 17 ;
a[93][14].action = 1 ;
a[93][14].state = 18 ;
a[93][15].action = 1 ;
a[93][15].state = 19 ;
a[93][22].action = 1 ;
a[93][22].state = 20 ;
a[93][23].action = 1 ;
a[93][23].state = 21 ;
a[93][36].action = 4 ;
a[93][36].state = 95 ;
a[93][37].action = 4 ;
a[93][37].state = 3 ;
a[93][38].action = 4 ;
a[93][38].state = 4 ;
a[93][39].action = 4 ;
a[93][39].state = 5 ;
a[93][40].action = 4 ;
a[93][40].state = 6 ;
a[93][41].action = 4 ;
a[93][41].state = 7 ;
a[93][42].action = 4 ;
a[93][42].state = 8 ;
a[93][43].action = 4 ;
a[93][43].state = 9 ;
a[93][52].action = 4 ;
a[93][52].state = 12 ;
a[93][53].action = 4 ;
a[93][53].state = 13 ;


a[94][2].action = 1 ;
a[94][2].state = 10 ;
a[94][5].action = 1 ;
a[94][5].state = 11 ;
a[94][9].action = 2 ;
a[94][9].state = 2 ;
a[94][10].action = 1 ;
a[94][10].state = 14 ;
a[94][11].action = 1 ;
a[94][11].state = 15 ;
a[94][12].action = 1 ;
a[94][12].state = 16 ;
a[94][13].action = 1 ;
a[94][13].state = 17 ;
a[94][14].action = 1 ;
a[94][14].state = 18 ;
a[94][15].action = 1 ;
a[94][15].state = 19 ;
a[94][22].action = 1 ;
a[94][22].state = 20 ;
a[94][23].action = 1 ;
a[94][23].state = 21 ;
a[94][36].action = 4 ;
a[94][36].state = 96 ;
a[94][37].action = 4 ;
a[94][37].state = 3 ;
a[94][38].action = 4 ;
a[94][38].state = 4 ;
a[94][39].action = 4 ;
a[94][39].state = 5 ;
a[94][40].action = 4 ;
a[94][40].state = 6 ;
a[94][41].action = 4 ;
a[94][41].state = 7 ;
a[94][42].action = 4 ;
a[94][42].state = 8 ;
a[94][43].action = 4 ;
a[94][43].state = 9 ;
a[94][52].action = 4 ;
a[94][52].state = 12 ;
a[94][53].action = 4 ;
a[94][53].state = 13 ;

a[95][9].action = 1 ;
a[95][9].state = 97 ;

a[96][9].action = 1 ;
a[96][9].state = 98 ;

a[97][1].action = 2 ;
a[97][1].state = 35 ;
a[97][2].action = 2 ;
a[97][2].state = 35 ;
a[97][5].action = 2 ;
a[97][5].state = 35 ;
a[97][9].action = 2 ;
a[97][9].state = 35 ;
a[97][10].action = 2 ;
a[97][10].state = 35 ;
a[97][11].action = 2 ;
a[97][11].state = 35 ;
a[97][12].action = 2 ;
a[97][12].state = 35 ;
a[97][13].action = 2 ;
a[97][13].state = 35 ;
a[97][14].action = 2 ;
a[97][14].state = 35 ;
a[97][15].action = 2 ;
a[97][15].state = 35 ;
a[97][22].action = 2 ;
a[97][22].state = 35 ;
a[97][23].action = 2 ;
a[97][23].state = 35 ;

a[98][1].action = 2 ;
a[98][1].state = 25 ;
a[98][2].action = 2 ;
a[98][2].state = 25 ;
a[98][5].action = 2 ;
a[98][5].state = 25 ;
a[98][9].action = 2 ;
a[98][9].state = 25 ;
a[98][10].action = 2 ;
a[98][10].state = 25 ;
a[98][11].action = 2 ;
a[98][11].state = 25 ;
a[98][12].action = 2 ;
a[98][12].state = 25 ;
a[98][13].action = 2 ;
a[98][13].state = 25 ;
a[98][14].action = 2 ;
a[98][14].state = 25 ;
a[98][15].action = 2 ;
a[98][15].state = 25 ;
a[98][22].action = 2 ;
a[98][22].state = 25 ;
a[98][23].action = 2 ;
a[98][23].state = 25 ;

// Error filling


}
