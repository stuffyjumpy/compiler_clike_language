#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"
#include "Lexer.h"
#define ERROR 	0
#define SHIFT 	1
#define REDUCE 	2
#define ACCEPT 	3
#define BLANK 	4

//parse table entry
typedef struct cell1{
	int action;
	int state;
} cell;
const int plen[]=  {3,2,0,1,1,1,1,1,4,4,8,1,1,4,4,1,1,1,1,1,1,3,0,3,1,4,0,2,2,3,3,0,3,3,0,10,7,3,1,1,1,1,1,1,1,1,1,1};
const char *LHS[] = {"Program","S","S","Stmt","Stmt","Stmt","Stmt","Stmt","Decl","Assig","Cond","Loop","Loop","IO-stmt","IO-stmt","Data-type","Data-type","Data-type","Data-type","Value","Value","nDecl","nDecl","BoolE","BoolE","else-part","else-part","E","T","E1","E1","E1","T1","T1","T1","ForLoop","WhileLoop","BoolTerm","BoolOp","BoolOp","CompOp","CompOp","CompOp","CompOp","CompOp","Const","Const","Const"};
const char *Goto[] = {"Program","S","Stmt","Decl","Assig","Cond","Loop","IO-stmt","Data-type","Value","nDecl","BoolE","else-part","E","T","E1","T1","ForLoop","WhileLoop","BoolTerm","BoolOp","CompOp","Const"};

//find index of NT in parse table
int indexOf(char *NT);

//main parser
void parse(LTpair input[],int n,Tnode **rootptr);

//builds parse table
void initialize();

#endif
