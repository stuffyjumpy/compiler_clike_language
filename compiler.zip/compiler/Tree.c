#include "Tree.h"

//returns new node
Tnode * newTnode(char *lex){
	Tnode *temp = (Tnode *)malloc(sizeof(Tnode));
	strcpy(temp->text, lex);
	int i;
	for(i=0;i<10;i++){
		temp->child[i] = NULL;
	}
	return temp;
}

// prints level order
void levelPrint(Tnode *root){
	Tnode *queue[100000];
	int level[100000];
	int fr=0,back=-1;
	queue[++back]=root;
	level[back]=0;
	int print_level = 0;
	while(fr <= back){
		Tnode* curr = queue[fr];
		int L = level[fr++];			//popped
		if(L == print_level+1){
			printf("\n");
			print_level = L;
		}
		printf("%s(%d)  ",curr->text,L);
		int i;
		for(i=0;i<10;i++){
			if(curr->child[i]==NULL)
				break;
			queue[++back] = curr->child[i];	// children pushed
			level[back]= L+1;
		}
	}
	printf("\n");
}
