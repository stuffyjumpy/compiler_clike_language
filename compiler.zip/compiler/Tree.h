#ifndef TREE_H_INCLUDED
#define TREE_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//tree node struct
typedef struct tnode{
	char text[25];
	struct tnode* child[10];
} Tnode;

//create node
Tnode * newTnode(char *lex);

//level order traversal
void levelPrint(Tnode * root);

#endif
