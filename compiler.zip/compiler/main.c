#include<stdio.h>
#include<stdlib.h>
#include "Lexer.h"
#include "Tree.h"
int delim[300];
int line=1;

int main(int argc,char* argv[]){
	printf("\n");
	char d[]={'{', '}', '(', ')', '[', ']', ';', ','};		//delimiters
	int i;
	for(i=0;i<10;i++){
		delim[d[i]]=1;
	}
	FILE *fp;
	if(argv[1]==NULL){
		printf("Enter File name as: ./main.o code_file\n");
		return 0;
	}
	else{
		fp = fopen(argv[1],"r");
	}
	char buffer[1000000];
	char ch;
	i=0;
	while((ch=fgetc(fp))!=EOF){
		buffer[i++]=ch;
	}
	buffer[i]='\0';
	int k=0;
	char lexeme[100];	
	i=0;
	while(buffer[k]!='\0'){
		//multi-line comments
		if(lexeme[0]!='\"' && buffer[k]=='/' && buffer[k+1]=='*'){
			k+=2;
			while(buffer[k]!='\0' && !(buffer[k-2]=='*' && buffer[k-1]=='/')){
					if(buffer[k]=='\n')
						line++;
					k++;
			}
			if(buffer[k]=='\0'){
				printf("Line %d: Unterminated Comment.\n",line);
				return 0;
			}
		}
		//single-line comments
		if(lexeme[0]!='\"' && buffer[k]=='/' && buffer[k+1]=='/'){
			line++;
			k+=2;
			while(buffer[k-1]!='\n')
				k++;
			continue;
		}
		char ch=buffer[k];
		k++;
		if(ch==' ' || ch=='\t' || ch=='\n'){
			if(i==0){
				if(ch=='\n')
					line++;
				continue;
			}
			else{
				lexeme[i]='\0';
				printToken(lexeme, line);
				i=0;
				if(ch=='\n')
					line++;
			}
		}
		else if(delim[ch]==1){
			if(i!=0){
				lexeme[i]='\0';
				printToken(lexeme, line);
			}
			i=0;
			lexeme[i]=ch;
			lexeme[i+1]='\0';
			printToken(lexeme, line);
		}
		else{
			lexeme[i++]=ch;
		}
	}
	extern int inp_index;
	extern LTpair input[100000];
	strcpy(input[inp_index].lexeme,"$");
	input[inp_index].token = $;
	input[inp_index].line = input[inp_index-1].line;
	inp_index++;
	printf("\n\n\nLEXER OUTPUT\n\n\n");
	for(i=0;i<inp_index;i++){
		printf("Token no. : %d, Lexeme : %s, Line : %d\n",input[i].token,input[i].lexeme, input[i].line);
	}
	
	Tnode *root = NULL;
	//printf("\n\n\nPARSE TABLE\n\n\n");

	parse(input,inp_index,&root);
	//printf("\n\n\n\t\t\t\tLEVEL ORDER TRAVERSAL\n\n");
	//levelPrint(root);
	fclose(fp);
	return 0;
}
