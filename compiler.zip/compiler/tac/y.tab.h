#define ADD 257
#define SUB 258
#define MUL 259
#define DIV 260
#define EQ 261
#define COMMA 262
#define SEM 263
#define LB 264
#define RB 265
#define VAR 266
#define IF 267
#define ELSE 268
#define WHILE 269
#define ID 270
#define MAIN 271
#define FUNCTION 272
#define LFB 273
#define RFB 274
#define LSB 275
#define RSB 276
#define OR 277
#define AND 278
#define LT 279
#define GTE 280
#define EQEQ 281
#define NEQ 282
#define GT 283
#define LTE 284
#define FOR 285
#define NUM 286
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union 
  {
    int ival;
    char string[10];
  } YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
